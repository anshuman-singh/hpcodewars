angular.module('dashboard').controller('MessagesCtrl',function($scope){

	$('#myTab a').click(function (e) {
	  e.preventDefault()
	  $(this).tab('show')
	})
	
});