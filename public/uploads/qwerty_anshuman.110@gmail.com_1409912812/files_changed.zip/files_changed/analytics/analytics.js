angular.module('dashboard').controller('AnalyticsCtrl',function($scope){



});